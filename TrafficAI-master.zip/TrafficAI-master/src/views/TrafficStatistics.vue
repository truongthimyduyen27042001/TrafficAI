<template>
  <div class="traffic-statistics">
      <h1>This is traffic statistics</h1>
  </div>
</template>

<script>
export default {
    name: 'statistics'
}
</script>

<style lang="scss" scoped>
.traffic-statistics {
  width: 100vw;
  height: 100vh;
  background: yellow;
}
</style>