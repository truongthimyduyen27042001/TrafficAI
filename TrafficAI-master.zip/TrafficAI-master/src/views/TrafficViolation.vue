<template>
  <div class="traffic-violation">
      <h1>This is traffic violation</h1>
  </div>
</template>

<script>
export default {
    name: 'violation'
}
</script>

<style lang="scss" scoped>
.traffic-violation {
  width: 100vw;
  height: 100vh;
  background: green;
}

</style>