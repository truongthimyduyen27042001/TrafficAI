<template>
  <div class="error">
      <h1>This is error</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>