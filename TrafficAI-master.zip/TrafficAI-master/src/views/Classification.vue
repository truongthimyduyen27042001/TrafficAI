<template>
  <div class="classification">
      This is classification
  </div>
</template>

<script>
export default {
  name: 'classification'
}
</script>

<style lang="scss" scoped>
.classification {
  width: 100vw;
  height: 100vh;
  background: red;
}
</style>